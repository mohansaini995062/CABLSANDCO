import { CloudinaryStorage } from 'multer-storage-cloudinary';
import multer from 'multer';
import cloudinary from './cloudinaryConfig.js';

const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'profile_pictures', // Folder name in Cloudinary
    allowed_formats: ['jpg', 'jpeg', 'png'], // Acceptable file types
    public_id: (req, file) => `profile_${Date.now()}`, // Custom file name
  },
});

const upload = multer({ storage });

export default upload;
