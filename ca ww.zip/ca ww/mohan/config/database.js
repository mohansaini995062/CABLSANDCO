import mongoose from "mongoose"

const database = async()=>{
 try {
    await mongoose.connect(process.env.DB_URL);
    console.log("db connection success")
 } catch (error) {
    console.log(error)
 }
}


export default database;
