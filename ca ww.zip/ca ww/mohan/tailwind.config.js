module.exports = {
  content: [
    './views/**/*.ejs', // Adjust this path to match your EJS file locations
    './public/**/*.html', // Include other HTML files if needed
  ],
 
};
